﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using UserProfile.Core;
using UserProfile.Core.Enums;
using UserProfile.Data;
using UserProfileCreation.ViewModels;

namespace UserProfileCreation.Controllers
{
    public class UserController : Controller
    {
        private readonly IProfileData _profileData;
        private readonly IHtmlHelper _htmlHelper;
        public IEnumerable<Profile> GetProfile { get; set; }
        
        public UserController(IProfileData profileData,IHtmlHelper htmlHelper)
        {
            _profileData = profileData;
            _htmlHelper = htmlHelper;
        }
        public IActionResult Index()
        {
            GetProfile = _profileData.GetAll();
            return View(GetProfile);
        }
        [HttpGet]
        public ActionResult Edit(int? userId)
        {
            UserProfileViewModel userProfile = new UserProfileViewModel();
            //Get Title enum in the list
            userProfile.ListOfTitle = _htmlHelper.GetEnumSelectList<Title>();

            //Create empty list and add hobby enum in the list
            userProfile.Hobbies = new List<EnumModelHobby>();
            foreach (var hobby in Enum.GetValues(typeof(Hobbies)))
            {
                userProfile.Hobbies.Add(new EnumModelHobby() { Hobby = (Hobbies)hobby });
            }
            //Check the user Id has value or not and if yes then map the values else return empty view for create profile
            if (userId.HasValue)
            {
                var model = _profileData.GetProfile(userId.Value);

                userProfile.UserTitle = model.Title;
                userProfile.Hobbies.ForEach(d => d.IsSelected = model.Hobbie.Any(sd => sd.Hobby == d.Hobby));
                userProfile.UserDatePicker = model.DatePicker;
                userProfile.UserFouritePet = model.FouritePet;
            }
            else
            {
                return View(userProfile);
            }

            return View(userProfile);
        }
        [HttpPost]
        public ActionResult Edit(UserProfileViewModel viewModel)
        {
            //Get enum of title in the list
            viewModel.ListOfTitle = _htmlHelper.GetEnumSelectList<Title>();
            
            //Map profile to viewmodel
            Profile profile = new Profile();
            profile.Title = viewModel.UserTitle;
            profile.Id = viewModel.UserId;
            profile.FouritePet = viewModel.UserFouritePet;
            profile.DatePicker = viewModel.UserDatePicker;
            profile.Hobbie = new List<EnumModelHobby>();
            profile.Hobbie = (from p in viewModel.Hobbies
                             where p.IsSelected == true
                             select p).ToList();
            //If userId has value greater than 0 then edit it else create new profile.
            if (viewModel.UserId > 0)
            {
                var model = _profileData.Update(profile);
            }
            else
            {
                _profileData.Add(profile);
            }
            return View(viewModel);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return RedirectToAction("Edit","User");
        }
        [HttpPost]
        public ActionResult Create(UserProfileViewModel viewModel)
        {
            return RedirectToAction("Edit",viewModel);
        }
    }
}
