﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserProfile.Core;
using UserProfile.Core.Enums;
using UserProfile.Data;

namespace UserProfileCreation.ViewModels
{
    [Bind]
    public class UserProfileViewModel
    {
        internal List<Hobbies> UserHobbie;

        public int UserId { get; set; }
        public Title UserTitle { get; set; }
        public DateTime UserDatePicker { get; set; }
        public Pets UserFouritePet { get; set; }
        public IEnumerable<SelectListItem> ListOfTitle { get; set; }
        public List<EnumModelHobby> Hobbies { get; set; }
    }
}
