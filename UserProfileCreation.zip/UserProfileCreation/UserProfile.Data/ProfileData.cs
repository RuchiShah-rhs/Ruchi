﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using UserProfile.Core;

namespace UserProfile.Data
{
    public class ProfileData : IProfileData
    {
        private readonly UserProfileContext db;

        public ProfileData(UserProfileContext db)
        {
            this.db = db;
        }
        public Profile Add(Profile newProfile)
        {
            db.Add(newProfile);
            return newProfile;
        }

        public IEnumerable<Profile> GetAll()
        {
           var profile = from p in db.Profile
                         select p;
            return profile;
        }

        public Profile GetProfile(int id)
        {
            return db.Profile.Find(id);
        }

        public Profile Update(Profile profile)
        {
           var entity = db.Profile.Attach(profile);
            entity.State = EntityState.Modified;
            return profile;

        }
    }
}
