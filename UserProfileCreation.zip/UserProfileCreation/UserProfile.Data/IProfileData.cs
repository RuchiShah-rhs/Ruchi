﻿using System;
using System.Collections.Generic;
using System.Text;
using UserProfile.Core;

namespace UserProfile.Data
{
    public interface IProfileData
    {
        IEnumerable<Profile> GetAll();
        Profile GetProfile(int id);

        Profile Update(Profile profile);

        Profile Add(Profile profile);
    }
}
