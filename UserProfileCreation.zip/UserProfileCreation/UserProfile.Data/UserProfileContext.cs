﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using UserProfile.Core;

namespace UserProfile.Data
{
    public class UserProfileContext:DbContext
    {
        public UserProfileContext(DbContextOptions<UserProfileContext> options):base(options)
        {
        }
        public DbSet<Profile> Profile { get; set; }
        public DbSet<EnumModelHobby> Hobby { get; set; }
    }
}
