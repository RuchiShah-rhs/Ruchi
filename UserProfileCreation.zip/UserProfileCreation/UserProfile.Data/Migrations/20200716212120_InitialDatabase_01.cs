﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace UserProfile.Data.Migrations
{
    public partial class InitialDatabase_01 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Hobby_Profile_ProfileId",
                table: "Hobby");

            migrationBuilder.AlterColumn<int>(
                name: "ProfileId",
                table: "Hobby",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Hobby_Profile_ProfileId",
                table: "Hobby",
                column: "ProfileId",
                principalTable: "Profile",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Hobby_Profile_ProfileId",
                table: "Hobby");

            migrationBuilder.AlterColumn<int>(
                name: "ProfileId",
                table: "Hobby",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Hobby_Profile_ProfileId",
                table: "Hobby",
                column: "ProfileId",
                principalTable: "Profile",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
