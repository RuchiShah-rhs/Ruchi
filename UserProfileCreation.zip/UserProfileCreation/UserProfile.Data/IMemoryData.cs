﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UserProfile.Core;
using UserProfile.Core.Enums;

namespace UserProfile.Data
{
    public class IMemoryData : IProfileData
    {
        public readonly List<Profile> Profiles;

        public IMemoryData()
        {
            Profiles = new List<Profile>
            {
                new Profile{Id=1,Title=Title.Mr,DatePicker=DateTime.Today,FouritePet=Pets.Cat,Hobbie=new List<EnumModelHobby> { new EnumModelHobby{ Hobby=Hobbies.Cooking,IsSelected=true } } },
                new Profile{Id=2,Title=Title.Mrs,DatePicker=DateTime.Today,FouritePet=Pets.Dog,Hobbie=new List<EnumModelHobby> { new EnumModelHobby{ Hobby=Hobbies.Gardening,IsSelected=true } } },
                new Profile{Id=3,Title=Title.Miss,DatePicker=DateTime.Today,FouritePet=Pets.Parrot,Hobbie=new List<EnumModelHobby> { new EnumModelHobby{ Hobby=Hobbies.painting,IsSelected=true } } },
                new Profile{Id=4,Title=Title.Mrs,DatePicker=DateTime.Today,FouritePet=Pets.Dog,Hobbie=new List<EnumModelHobby> { new EnumModelHobby{ Hobby=Hobbies.Writting,IsSelected=true } }},
            };
        }

        public Profile Add(Profile profile)
        {
            Profiles.Add(profile);
            profile.Id = Profiles.Max(p => p.Id + 1);
            return profile;
        }

        public IEnumerable<Profile> GetAll()
        {
            var listOfProfile = from p in Profiles
                                select p;
            return listOfProfile;
        }

        public Profile GetProfile(int id)
        {
            return Profiles.SingleOrDefault(p => p.Id == id);
        }

        public Profile Update(Profile profle)
        {
            var updateProfile = Profiles.SingleOrDefault(p => p.Id == profle.Id);
            if(updateProfile != null)
            {
                updateProfile.Title = profle.Title;
                updateProfile.Hobbie = profle.Hobbie;
                updateProfile.FouritePet = profle.FouritePet;
                updateProfile.DatePicker = profle.DatePicker;

            }
            return updateProfile;
        }
    }
}
