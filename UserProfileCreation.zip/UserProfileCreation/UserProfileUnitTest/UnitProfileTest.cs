using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using UserProfile.Core;
using UserProfile.Data;

namespace UserProfileUnitTest
{
    [TestFixture]
    public class UnitProfileTest
    {
        private Mock<IProfileData> profileData;
        private List<Profile> EnumeratedProfile;
        private IMemoryData memoryData;
        public UnitProfileTest()
        {
            
        }
        [TestInitialize]
        public void Initialize()
        {
            EnumeratedProfile = memoryData.Profiles;
            profileData = new Mock<IProfileData>();
            profileData.Setup(m => m.GetAll()).Returns(EnumeratedProfile);
            
            memoryData = new IMemoryData();
        }

            [Test]
        public void GetAllProfileTest()
        {
            int id = 2;
            var profileList =memoryData.GetProfile(id);
        }
    }
}