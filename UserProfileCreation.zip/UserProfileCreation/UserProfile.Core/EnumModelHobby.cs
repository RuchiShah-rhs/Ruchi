﻿using System;
using System.Collections.Generic;
using System.Text;
using UserProfile.Core.Enums;

namespace UserProfile.Core
{
    public class EnumModelHobby
    {
        public int Id { get; set; }
        public Hobbies Hobby { get; set; }
        public bool IsSelected { get; set; }
        public Profile Profile { get; set; }
    }
}
