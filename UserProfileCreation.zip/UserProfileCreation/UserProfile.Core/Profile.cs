﻿using System;
using System.Collections.Generic;
using System.Text;
using UserProfile.Core.Enums;
using UserProfile.Data;

namespace UserProfile.Core
{
    public class Profile
    {
        public int Id { get; set; }
        public Title Title { get; set; }
        public DateTime DatePicker { get; set; }
        public Pets FouritePet { get; set; }
        public List<EnumModelHobby> Hobbie { get; set; }
    }
}
