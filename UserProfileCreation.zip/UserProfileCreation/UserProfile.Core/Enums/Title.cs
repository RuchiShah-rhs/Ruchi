﻿namespace UserProfile.Data
{
    public enum Title
    {
        Mr,
        Mrs,
        Miss,
        Ms,
        Master,
        Dr
    }
}
