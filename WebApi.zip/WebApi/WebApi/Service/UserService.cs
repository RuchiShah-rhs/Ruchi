﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Data;

namespace WebApi.Service
{
    public class UserService : IUser
    {
        private readonly UserDbContext userDbContext;

        public UserService(UserDbContext userDbContext)
        {
            this.userDbContext = userDbContext;
        }
        public User Add(User user)
        {
            userDbContext.Add(user);
            return user;
        }
    }
}
