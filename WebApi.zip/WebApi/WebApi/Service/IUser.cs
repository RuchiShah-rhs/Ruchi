﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Service
{
    public interface IUser
    {
        User Add(User user);
    }
}
